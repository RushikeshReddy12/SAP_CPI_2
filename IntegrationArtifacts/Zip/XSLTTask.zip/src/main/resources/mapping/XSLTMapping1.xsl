<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:ns2="http://changeorder.hybris.floonetwork.sac.shimano.com/"
    xmlns:ns3="http://getinvoice.hybris.floonetwork.sac.shimano.com/"
    xmlns:ns4="http://itemavailability.hybris.floonetwork.sac.shimano.com/"
    xmlns:ns5="http://neworder.b2b.hybris.floonetwork.sac.shimano.com/"
    exclude-result-prefixes="xsl SOAP-ENV ns2 ns3 ns4 ns5">

    <xsl:template match="/">
        <root>
            <xsl:for-each select="SOAP-ENV:Envelope/SOAP-ENV:Body/ns2:SendChangeOrder/ns2:order">
                <erpOrderNumber><xsl:value-of select="ns2:orderHeader/ns2:jdeNumber"/></erpOrderNumber>
                <soldTo><xsl:value-of select="ns2:orderHeader/ns2:billToNumber"/></soldTo>
                <shipTo><xsl:value-of select="ns2:orderHeader/ns2:shipToNumber"/></shipTo>
                <changeOrderType><xsl:value-of select="ns2:changeOrderType"/></changeOrderType>
                
                    <xsl:for-each select="ns2:orderLines/ns2:OrderLine">
                        <entries>
                            <erpLineNumber><xsl:value-of select="ns2:originalLineNumber div 100"/></erpLineNumber>
                            <changeLineType><xsl:value-of select="ns2:changeLineType"/></changeLineType>
                            <originalQty><xsl:value-of select="ns2:qty"/></originalQty>
                            <modifiedQty>
                                <xsl:choose>
                                    <xsl:when test="ns2:changeLineType = 'ADD_QTY'"><xsl:value-of select="ns2:addQty"/></xsl:when>
                                    <xsl:when test="ns2:changeLineType = 'SUBTRACT_QTY'"><xsl:value-of select="ns2:cancelQty"/></xsl:when>
                                </xsl:choose>
                            </modifiedQty>
                        </entries>
                    </xsl:for-each>
                
            </xsl:for-each>
        </root>
    </xsl:template>

</xsl:stylesheet>